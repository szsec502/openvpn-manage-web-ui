package pkg

func fn() {
	x := 1
	y := ""
	_ = x + y
}

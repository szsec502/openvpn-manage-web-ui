package initial

import _ "fmt"
import renamedfmt "fmt"
import renamedfmt2 "fmt"
import . "fmt"

func baz() {
	renamedfmt.Println()
	renamedfmt2.Println()
	Println()
}

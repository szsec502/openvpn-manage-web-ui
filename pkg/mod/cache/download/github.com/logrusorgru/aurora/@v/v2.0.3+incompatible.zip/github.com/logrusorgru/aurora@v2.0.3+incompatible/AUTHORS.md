AUTHORS
=======

- Konstantin Ivanov @logrusorgru
- Mattias Eriksson @snaggen
- Ousmane Traore @otraore
- Simon Legner @simon04
- Sevenate @sevenate

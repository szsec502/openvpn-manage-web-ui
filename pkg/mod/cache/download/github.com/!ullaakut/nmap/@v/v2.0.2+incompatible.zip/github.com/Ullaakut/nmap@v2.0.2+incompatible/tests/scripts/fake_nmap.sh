#!/bin/bash

cat $1


Library for interacting with [OpenVPN Management Interface](https://openvpn.net/index.php/open-source/documentation/miscellaneous/79-management-interface.html)

### Summary 

### Steps to reproduce the behavior

### gosec version

### Go version (output of 'go version')

### Operating system / Environment

### Expected behavior

### Actual behavior

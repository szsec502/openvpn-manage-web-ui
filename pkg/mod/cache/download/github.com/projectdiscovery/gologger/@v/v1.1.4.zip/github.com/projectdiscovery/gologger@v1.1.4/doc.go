// Package gologger provides a simple layer for leveled logging in go.
package gologger
